import Routes from './components/Routes';
import './App.css';
import { AppProvider } from './components/context';
function App() {
  return (
    <AppProvider>
      <div className="App">
        <Routes />
      </div>
    </AppProvider>
  );
}

export default App;
