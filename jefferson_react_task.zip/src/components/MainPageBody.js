import React,{useState} from "react";
import { Button, Grid,Typography,Container,makeStyles, TextField  } from '@material-ui/core';
import {SearchOutlined } from "@material-ui/icons";
import Fab from '@material-ui/core/Fab';
import { AppContext } from '../components/context';
import history from './history';
import ScrollMenu from 'react-horizontal-scrolling-menu';
import axios from "axios";
import Images from "./Images";
import '../App.css';
export default function Body() {
    const { setImages} = React.useContext(AppContext);
    const adjectives = ["amphibious","androgynous","anthropoid","aquatic","arboreal","articulate","asexual","caged"]
    const classes = useStyles();
    const [searchKey,setSearchKey]=useState("");
    const adjective = adjectives[Math.floor(Math.random()*adjectives.length)];
    const { innerWidth,innerHeight } = window;
    const searchOptions = {
        method: 'GET',
        url: 'https://google-search3.p.rapidapi.com/api/v1/images/q='+adjective+' '+searchKey,
        headers: {
          'x-rapidapi-key': '874f3f7ebcmshf0918d751c639c4p1b9288jsnc88d532ee945',
          'x-rapidapi-host': 'google-search3.p.rapidapi.com'
        }
    };
    const search_animal = () =>{
        axios.request(searchOptions).then(function (response) {
            setImages(response.data.image_results);
        }).catch(function (error) {
            console.error(error);
        });
    }
    React.useEffect(()=>{},[])
    return (
        <Container maxWidth="xl" component="main" className={classes.heroContent} >
            <div className={classes.root}>
                <Grid container style={{height:innerHeight * 0.80,marginTop:50}}>
                    <Grid item xs={12} sm={6}>
                        <div style={{padding:50}}>
                            <center><h1 style={{fontFamily:"sans-serif",color:'#3f4750'}}>ANIMAL FINDER</h1></center>
                            <center><p style={{color:'#757575'}}>Type your favorite animal below and we will show its beautiful image. We use google api for this buddy!</p></center>
                            <TextField
                                required
                                id="outlined-required"
                                label="Required"
                                placeholder="Enter animal name"
                                variant="outlined"
                                style={{width:'80%'}}
                                onKeyUp={(e)=>setSearchKey(e.target.value)}
                                inputProps={{ maxLength: 20 }}
                            />
                            <center><Button onClick={search_animal} style={{borderTopRightRadius:30,borderBottomLeftRadius:30}} className={classes.button} variant="outlined">Get Animal</Button></center>
                        </div>
                        <div className={classes.root}>
                            <ScrollMenu
                                data={adjectives.map((item, i) => (
                                    <div key={item} style={{margin:10,borderRadius:20,color:'#fff',backgroundColor:'#757575',padding:7}}>
                                        {item}           
                                    </div>
                                ))}
                            />
                        </div>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                        <Images />
                    </Grid>
                </Grid>
                <div style={{backgroundImage: "linear-gradient(180deg,#fff, #a4d4f3)",height:innerHeight * 0.20,width:innerWidth}}></div>
            </div>
            <Fab color="primary" onClick={()=>setSearchKey("")} aria-label="add" style={{position:'fixed',bottom:10,right:10}}>
                <SearchOutlined />
            </Fab>
        </Container>
    )
}
const useStyles = makeStyles((theme) => ({
    '@global': {
      ul: {
        margin: 0,
        padding: 0,
        listStyle: 'none',
      },
    },
    heroContent: {
      padding: theme.spacing(8, 0, 6),
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    },
    root: {
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-around',
        overflow: 'hidden',
    },
    gridList: {
        flexWrap: 'nowrap'
    },
    icon: {
        marginRight: theme.spacing(2),
    },
    heroButtons: {
        marginTop: theme.spacing(4),
    },
    cardGrid: {
        paddingTop: theme.spacing(8),
        paddingBottom: theme.spacing(8),
    },
    card: {
        display: 'flex',
        flexDirection: 'column',
    },
        cardMedia: {
        paddingTop: '56.25%', // 16:9
    },
        cardContent: {
        flexGrow: 1,
    },
    button: {
        marginTop:15,borderColor:'#3488a7',color:'#3488a7',outline:'none',
        '&:hover': {
          backgroundColor: '#3488a7',
          color: '#fff',
        }
    },
    footer: {
        backgroundColor: theme.palette.background.paper,
        padding: theme.spacing(6),
    },
}));