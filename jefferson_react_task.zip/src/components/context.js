import React from 'react';
export const AppContext = React.createContext();

export const AppProvider = (props) =>{
    const [images,setImages]=React.useState([]);
    React.useEffect(()=>{},[])
    return(
        <AppContext.Provider value={{images,setImages}}>
            {props.children}
        </AppContext.Provider>
    )
}