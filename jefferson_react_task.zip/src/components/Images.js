import React from "react";
import { Theme, createStyles, makeStyles } from '@material-ui/core/styles';
import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
import { AppContext } from '../components/context';
import img1 from '../img/banner.gif';
export default function Blog() {
    const { images} = React.useContext(AppContext);
    const classes = useStyles();
    React.useEffect(()=>{
        console.log(images)
    },[images])
    return (
        <div>
            {images.length > 0 ?(
                <div className={classes.root}>
                    <GridList cellHeight={160} className={classes.gridList} cols={3}>
                        {images.map((image,i) => (
                            <GridListTile key={i} cols={1}>
                                <img src={image.image.src} alt={image.image.src} />
                            </GridListTile>
                        ))}
                    </GridList>
                </div>
            ):(
                <center><img alt="" src={img1} style={{maxWidth:'75%'}}/></center>
            )}
        </div>
    );
}
const useStyles = makeStyles((theme) => ({
    root: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-around',
      overflow: 'hidden',
      borderColor:'#757575',
      borderWidth:2,
      borderRadius:10,
      backgroundColor: theme.palette.background.paper,
      padding:5,
    },
    gridList: {
      width: 500,
      height: 450,
    },
}));
  